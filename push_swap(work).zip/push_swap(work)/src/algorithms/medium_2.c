/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   medium_2.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jsilva-r <jsilva-r@student.42porto.com>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/05 15:21:53 by husobral          #+#    #+#             */
/*   Updated: 2026/08/06 11:34:35 by jsilva-r         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h"

void    assign_indexes(t_node *stack)
{
    t_node  *current;
    t_node  *min;
    int     index;

    current = stack;
    while (current)
    {
        current->index = -1;
        current = current->next;
    }
    index = 0;
    min = find_unindexed_min(stack);
    while (min)
    {
        min->index = index;
        index++;
        min = find_unindexed_min(stack);
    }
}

int     int_sqrt(int n)
{
    int i;

    i = 0;
    while ((i + 1) * (i + 1) <= n)
        i++;
    return (i);
}