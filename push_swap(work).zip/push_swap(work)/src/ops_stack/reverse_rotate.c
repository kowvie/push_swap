/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   reverse_rotate.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: husobral <husobral@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/05 11:32:53 by husobral          #+#    #+#             */
/*   Updated: 2026/08/05 11:32:53 by husobral         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h"

void    reverse_rotate(t_node **stack)
{
    t_node  *last;
    
    if (!stack || !*stack || !(*stack)->next)
        return ;
    last = last_node(*stack);
    last->prev->next = NULL;
    last->next = *stack;
    (*stack)->prev = last;
    *stack = last;
    last->prev = NULL;
}

void    rra(t_node **a, t_bench *bench)
{
    if (!a || !*a || !(*a)->next)
        return ;
    reverse_rotate(a);
    print_op("rra");
    bench_count(bench, OP_RRA);
}

void    rrb(t_node **b, t_bench *bench)
{
    if (!b || !*b || !(*b)->next)
        return ;
    reverse_rotate(b);
    print_op("rrb");
    bench_count(bench, OP_RRB);
}

void    rrr(t_node **a, t_node **b, t_bench *bench)
{
    if ((!a || !*a || !(*a)->next) && (!b || !*b || !(*b)->next))
        return ;
    reverse_rotate(a);
    reverse_rotate(b);
    print_op("rrr");
    bench_count(bench,OP_RRR);
}